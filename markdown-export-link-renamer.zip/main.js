"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const obsidian_1 = require("obsidian");
const obsidian_2 = require("obsidian");
/**
 * 画像リネーム確認用モーダル
 */
class RenameConfirmModal extends obsidian_1.Modal {
    constructor(app, onSubmit) {
        super(app);
        this.onSubmit = onSubmit;
    }
    onOpen() {
        const { contentEl } = this;
        contentEl.createEl('h2', { text: "Rename image files?" });
        new obsidian_1.Setting(contentEl)
            .addButton(btn => btn.setButtonText("Rename")
            .setCta()
            .onClick(() => {
            this.close();
            this.onSubmit(true);
        }))
            .addButton(btn => btn.setButtonText("Keep original")
            .onClick(() => {
            this.close();
            this.onSubmit(false);
        }));
    }
    onClose() {
        this.contentEl.empty();
    }
}
const DEFAULT_SETTINGS = {
    exportDir: "export"
};
class MdExportPlugin extends obsidian_1.Plugin {
    async onload() {
        await this.loadSettings();
        this.addSettingTab(new MdExporterSettingTab(this.app, this));
        this.addCommand({
            id: 'md-exporter-export-selected',
            name: 'Export selected note',
            callback: () => this.exportSelectedNote()
        });
        // ファイルメニュー（右クリック）に直接追加するイベントリスナー
        this.registerEvent(this.app.workspace.on('file-menu', (menu, file) => {
            if (file instanceof obsidian_1.TFile && file.extension === 'md') {
                menu.addItem((item) => {
                    item
                        .setTitle('Export from file menu')
                        .setIcon('paper-plane')
                        .onClick(() => {
                        this.exportSelectedNote(file);
                    });
                });
            }
        }));
    }
    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }
    async saveSettings() {
        await this.saveData(this.settings);
    }
    async exportSelectedNote(file) {
        const activeFile = file ?? this.app.workspace.getActiveFile();
        if (!activeFile) {
            new obsidian_1.Notice('Please open the note to export!');
            return;
        }
        // 設定値からvault直下のパスを生成
        const vaultBase = this.app.vault.adapter.basePath;
        const path = window.require ? window.require('path') : null;
        let exportDir = path ? path.join(vaultBase, this.settings.exportDir) : this.settings.exportDir;
        // ファイル名と同じディレクトリを追加
        if (path) {
            const baseName = activeFile.basename;
            exportDir = path.join(exportDir, baseName);
        }
        // 画像リネームモーダルだけ出す
        new RenameConfirmModal(this.app, async (doRename) => {
            const mdContent = await this.app.vault.read(activeFile);
            const mdLinks = this.extractLinks(mdContent);
            await this.exportWithLinks(activeFile, mdContent, mdLinks, exportDir, doRename, new Set());
        }).open();
    }
    extractLinks(mdContent) {
        // Obsidian型: ![[...]]
        const imageLinks = Array.from(mdContent.matchAll(/!\[\[(.+?)\]\]/g)).map(match => match[1]);
        // Markdown標準: ![alt](path)
        const mdImgLinks = Array.from(mdContent.matchAll(/!\[[^\]]*\]\(([^\)]+)\)/g)).map(match => match[1]);
        // URLデコード対応
        function safeDecode(s) {
            try {
                return decodeURIComponent(s);
            }
            catch {
                return s;
            }
        }
        const decodedImages = Array.from(new Set([
            ...imageLinks,
            ...mdImgLinks.map(safeDecode)
        ]));
        const mdLinks = Array.from(mdContent.matchAll(/\[\[(.+?)\]\]/g)).map(match => match[1]).filter(link => !link.endsWith('.png') && !link.endsWith('.jpg'));
        return { images: decodedImages, mdFiles: mdLinks };
    }
    async exportWithLinks(activeFile, mdContent, mdLinks, exportDir, doRename, exportedSet) {
        try {
            const fs = window.require ? window.require('fs') : null;
            const path = window.require ? window.require('path') : null;
            const Buffer = window.require ? window.require('buffer').Buffer : null;
            if (!fs || !path || !Buffer) {
                new obsidian_1.Notice('Export failed: fs, path, or Buffer module not available.');
                return;
            }
            // 既にエクスポート済みならスキップ（循環参照防止）
            if (exportedSet.has(activeFile.path)) {
                return;
            }
            exportedSet.add(activeFile.path);
            // ディレクトリ作成
            if (!fs.existsSync(exportDir)) {
                fs.mkdirSync(exportDir, { recursive: true });
            }
            // mdファイル出力
            const outMdPath = path.join(exportDir, activeFile.basename + '.md');
            fs.writeFileSync(outMdPath, mdContent, 'utf-8');
            // linked-images出力
            const linkedImagesDir = path.join(exportDir, 'linked-images');
            if (!fs.existsSync(linkedImagesDir)) {
                fs.mkdirSync(linkedImagesDir, { recursive: true });
            }
            const imageNameMap = {};
            mdLinks.images.forEach((origImg, idx) => {
                if (doRename) {
                    // image01, image02... + 拡張子
                    const ext = path.extname(origImg) || '.png';
                    const num = String(idx + 1).padStart(2, '0');
                    imageNameMap[origImg] = `image${num}${ext}`;
                }
                else {
                    imageNameMap[origImg] = origImg;
                }
            });
            for (const origImg of mdLinks.images) {
                let imgFile = null;
                let candidatePath = '';
                // 画像リンクがパス付き（/や../含む）なら、そのままVault直下から参照
                if (origImg.includes('/') || origImg.startsWith('.')) {
                    candidatePath = path.normalize(origImg);
                    imgFile = this.app.vault.getAbstractFileByPath(candidatePath);
                }
                // ファイル名だけの場合は、ノートのディレクトリから上の階層を順にたどる
                if (!imgFile && !origImg.includes('/')) {
                    const notePathParts = activeFile.path.split('/');
                    notePathParts.pop(); // ノート自身を除外
                    while (notePathParts.length > 0) {
                        candidatePath = [...notePathParts, origImg].join('/');
                        imgFile = this.app.vault.getAbstractFileByPath(candidatePath);
                        if (imgFile)
                            break;
                        notePathParts.pop();
                    }
                }
                // attachments等のよくあるディレクトリで探す
                if (!imgFile) {
                    for (const dir of ['attachments', 'Assets', 'asset', 'images', 'image']) {
                        candidatePath = `${dir}/${origImg}`;
                        imgFile = this.app.vault.getAbstractFileByPath(candidatePath);
                        if (imgFile)
                            break;
                    }
                }
                // Vault全体で検索（最初に見つかったもの）
                if (!imgFile) {
                    const files = this.app.vault.getFiles();
                    imgFile = files.find(f => f.name === origImg) || null;
                }
                if (imgFile instanceof obsidian_1.TFile) {
                    try {
                        new obsidian_1.Notice(`Copying image file: ${imgFile.path} → linked-images/${imageNameMap[origImg]}`);
                        const data = await this.app.vault.readBinary(imgFile);
                        if (data) {
                            const outPath = path.join(linkedImagesDir, imageNameMap[origImg]);
                            fs.writeFileSync(outPath, Buffer.from(data));
                            // 画像リンクを新しいパスに書き換え
                            // Obsidian型
                            mdContent = mdContent.split(`![[${origImg}]]`).join(`![[linked-images/${imageNameMap[origImg]}]]`);
                            // Markdown標準型
                            mdContent = mdContent.replace(new RegExp(`!\\[[^\\]]*\\]\\(${origImg.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")}\\)`, 'g'), `![](/linked-images/${imageNameMap[origImg]})`);
                        }
                        else {
                            new obsidian_1.Notice(`Image export failed: ${imgFile.path} is empty.`);
                        }
                    }
                    catch (e) {
                        new obsidian_1.Notice(`Image export failed: ${e?.message || e}`);
                    }
                }
                else {
                    new obsidian_1.Notice(`Image file not found: ${origImg}`);
                }
            }
            // mdリンクを再帰的にエクスポート
            for (const mdLink of mdLinks.mdFiles) {
                let linkMdFile = null;
                let candidatePath = '';
                // まず相対パスで探す
                candidatePath = mdLink + '.md';
                linkMdFile = this.app.vault.getAbstractFileByPath(candidatePath);
                // attachments等のよくあるディレクトリで探す
                if (!linkMdFile) {
                    for (const dir of ['attachments', 'Assets', 'asset', 'images', 'image']) {
                        candidatePath = `${dir}/${mdLink}.md`;
                        linkMdFile = this.app.vault.getAbstractFileByPath(candidatePath);
                        if (linkMdFile)
                            break;
                    }
                }
                // Vault全体でbasename一致で探す
                if (!linkMdFile) {
                    const files = this.app.vault.getFiles();
                    for (const file of files) {
                        if (file.basename === mdLink) {
                            linkMdFile = file;
                            break;
                        }
                    }
                }
                if (linkMdFile instanceof obsidian_1.TFile) {
                    new obsidian_1.Notice(`Exporting linked note: ${mdLink}.md`);
                    const linkMdContent = await this.app.vault.read(linkMdFile);
                    const linkMdLinks = this.extractLinks(linkMdContent);
                    // サブディレクトリを作成
                    const subDir = path.join(exportDir, mdLink);
                    // 再帰的にエクスポート
                    await this.exportWithLinks(linkMdFile, linkMdContent, linkMdLinks, subDir, doRename, exportedSet);
                }
                else {
                    new obsidian_1.Notice(`Linked note not found: ${mdLink}.md`);
                }
            }
            new obsidian_1.Notice('Export completed!');
        }
        catch (e) {
            new obsidian_1.Notice('Export failed: ' + (e?.message || e));
        }
    }
}
class MdExporterSettingTab extends obsidian_2.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        containerEl.createEl("h2", { text: "Markdown Export Link Renamer Settings" });
        new obsidian_1.Setting(containerEl)
            .setName("Export directory")
            .setDesc("Specify a relative path from the vault root (e.g., export)")
            .addText(text => text
            .setPlaceholder("export")
            .setValue(this.plugin.settings.exportDir)
            .onChange(async (value) => {
            this.plugin.settings.exportDir = value;
            await this.plugin.saveSettings();
        }));
    }
}
exports.default = MdExportPlugin;
